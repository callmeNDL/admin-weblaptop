export const DATE_PARSE = 'DD-MM-YYYY HH:mm';
