const ProvinceActionTypes = {
  SET_PROVINCE: 'SET_PROVINCE',
}

export default ProvinceActionTypes
